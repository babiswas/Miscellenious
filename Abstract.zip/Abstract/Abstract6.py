from collections import Counter


l=['hello','bello','mello','bello','melllo','tello']
m=Counter(l)
print(m)
