from abc import ABC,abstractmethod
class Visitor(ABC):

   def __init__(self,name):
      self.name=name

   def __str__(self):
     return f"{self.name} is name"

   @abstractmethod
   def visit(self,house):
      pass

class House:
   def accept(self,visitor):
      visitor.visit(self)
   def work_on_elec(self,elec):
      print(f"{elec} working on electrics")
   def work_on_hvac(self,hvac):
      print(f"{hvac} working on hvac")

class Elec(Visitor):
   def __init__(self,name):
      self.name=name
   def visit(self,house):
       house.work_on_elec(self)

class Hvac(Visitor):
   def __init__(self,name):
       self.name=name
   def visit(self,house):
       house.work_on_hvac(self)

if __name__=="__main__":
   house=House()
   elec=Elec("test1")
   hvac=Hvac("test2")
   house.accept(elec)
   house.accept(hvac)


       
