#Chain of responsibility
from abc import ABC,abstractmethod

class Handler(ABC):
   def __init__(self,sucessor):
       self.sucessor=sucessor
   def handle(self,request):
      handled=self._handler(request)
      if not handled:
         self.sucessor.handle(request)
   @abstractmethod
   def _handler(self,request):
      pass

class DefaultHandler(Handler):
     def _handler(self,request):
         print(f"End of chain for {request}")
         return True

class CustomHandler(Handler):
   def _handler(self,request):
      if request>0 and request<=10:
         print(f"{request} is processed")
         return True
      else:
         return False

class Client:
   def __init__(self):
      self.handler=CustomHandler(DefaultHandler(None))
   def delegate(self,requests):
       for obj in requests:
           self.handler.handle(obj)

if __name__=="__main__":
   requests=[1,2,3,4,12,15,9,7]
   c1=Client()
   c1.delegate(requests)


