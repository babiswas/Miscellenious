class Node:
    def __init__(self,value):
        self.value=value
        self.left=None
        self.right=None


def height(node):
    count=0
    if not node:
        return 0
    else:
        queue=[]
        queue.append(node)
        while queue:
            q_len=len(queue)
            count=count+1
            while q_len:
                m=queue.pop(0)
                if m.left:
                    queue.append(m.left)
                if m.right:
                    queue.append(m.right)
                q_len=q_len-1
        return count


def diameter(node):
    left=0
    right=0
    h_left=0
    h_right=0
    if not node:
        return 0
    else:
        if node.left:
            left=diameter(node.left)
        if node.right:
            right=diameter(node.right)
        if node.left:
            h_left=height(node.left)
        if node.right:
            h_right=height(node.right)
        return max(h_left+h_right+1,max(left,right))

if __name__=="__main__":
    node=Node(12)
    node.left=Node(13)
    node.right=Node(1)
    node.left.left=Node(11)
    node.left.right=Node(10)
    node.right.left=Node(14)
    node.right.right=Node(16)
    node.right.right.right=Node(19)
    node.right.right.right.right=Node(34)
    node.right.left.left=Node(11)
    node.right.left.left.left=Node(14)
    node.right.left.left.left.left=Node(90)
    print(diameter(node))



    



         