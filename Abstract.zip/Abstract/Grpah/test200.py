import json
import time

class User:
   def __init__(self,user_attribute):
      self.type="user"
      self.attributes=user_attribute.__dict__
   @property
   def set_attribute(self):
       return self.attributes
   @set_attribute.setter
   def set_attribute(self,obj):
      self.attributes=obj.__dict__

class User_Attribute:
   def __init__(self,email,name,uuid,**kwargs):
      self.email=str(email)
      self.name=str(name)
      self.userUniqueId=str(uuid)
      self.roles=["learner"]
      self.state="Active"
      self.userType="INTERNAL"
      for i,j in kwargs:
         self.fields[str(i)]=str(j)

def user_payload(obj):
   return json.dumps(obj.__dict__)

if __name__=="__main__":
   email=input("Enter email:")
   name=input("Enter name:")
   uuid=input("Enter uuid:")
   attrib=User_Attribute(email,name,uuid)
   print(json.dumps(attrib.__dict__)) 
   user=User(attrib)
   print(json.dumps(user.__dict__))
   print(user_payload(user))

   
   
   
   

      
