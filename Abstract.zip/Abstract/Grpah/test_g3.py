import types

class Strategy:
   def __init__(self,function=None):
      self.name="Default Strategy"
      if function:
        self.execute=types.MethodType(function,self)
   def execute(self):
      print(f"{self.name} is executed")

def execute1(self):
   print(f"{self.name} is executed")

def execute2(self):
  print(f"{self.name} is executed")

if __name__=="__main__":
   s1=Strategy()
   s1.execute()
   s2=Strategy(execute1)
   s2.name="test2"
   s2.execute()
   s3=Strategy(execute2)
   s3.name="test3"
   s3.execute()


