class Observer:
   def __init__(self):
      self.obj=[]

   def unregister(self,ob):
     if ob in self.obj:
        self.obj.remove(ob)

   def register(self,ob):
      if ob not in self.obj:
         self.obj.append(ob)

   def notify(self,message):
      for ob in self.obj:
         ob.update(message)

class Client:
   def __init__(self,name):
      self.name=name
   def update(self,message):
      print(f"{self.name} recieved {message}")

if __name__=="__main__":
  c1=Client("test1")
  c2=Client("test2")
  ob=Observer()
  ob.register(c1)
  ob.register(c2)
  ob.notify("hello everybody")

  