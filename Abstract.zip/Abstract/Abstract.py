from abc import ABC,abstractmethod

class A(ABC):
   def __init__(self,a):
      self.a=a
   @abstractmethod
   def seta(self,a):
       pass
   @abstractmethod
   def geta(self):
       pass

class B(A):
  def __init__(self,a,b):
      self.b=b
      A.__init__(self,a)
  def __str__(self):
      return f"{self.a} and {self.b}"
  def seta(self,a):
     self.a=a
  def geta(self):
     return self.a


if __name__=="__main__":
  b=B(2,3)
  print(b)
  b.seta(34)
  print(b.geta())

  