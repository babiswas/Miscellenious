class Obserable:
   def __init__(self):
      self.obj=[]
   def register(self,obj1):
      self.obj.append(obj1)
   def unregister(self,obj1):
      self.obj.remove(obj1)
   def notify(self,message):
       for i in self.obj:
         print(i.update(message))

class Observer:
    def __init__(self,name):
       self.name=name
    def update(self,str1):
      return f"{self.name} recieved {str1}"

if __name__=="__main__":
   a=Observer("test1")
   b=Observer("test2")
   c=Obserable()
   c.register(a)
   c.register(b)
   c.notify("hello")

       