def decorate(*args,**kwargs):
   def wrap(*d):
      for i in args:
        print(i)
      for i in kwargs.values():
        print(i)
      return d[0]
   return wrap

@decorate("hello","bello",test1="tello",test2="mello")
def fun(*args):
  for i in args:
     print(i)

if __name__=="__main__":
   fun(1,2,3,4)


