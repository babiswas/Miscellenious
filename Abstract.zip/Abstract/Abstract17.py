import types

class Strategy:
   def __init__(self,function=None):
       self.name="Default Strategy"
       if function:
         self.execute=types.MethodType(function,self)
   def execute(self):
      print(f"{self.name} is used to execute method")

def strategy_one(self):
    print(f"{self.name} is used to execute method1")

def strategy_two(self):
   print(f"{self.name} is used to execute method2")

if __name__=="__main__":
   s0=Strategy()
   s0.execute()
   s1=Strategy(strategy_one)
   s1.name="hello1"
   s1.execute()
   s2=Strategy(strategy_two)
   s2.name="hello2"
   s2.execute()
