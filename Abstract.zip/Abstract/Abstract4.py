class Mymeta(type):
   def __new__(metaclass,classname,baseclass,attrs):
      def fun1(self,a,b):
        return a+b
      attrs["hello"]=fun1
      return type.__new__(metaclass,classname,baseclass,attrs)
   def __init__(self,*args):
       pass

class A(metaclass=Mymeta):
    def __init__(self,a,b):
        self.a=a
        self.b=b
    def __str__(self):
       return f"{self.a} and {self.b}"


if __name__=="__main__":
   a=A(3,4)
   print(a)
   print(a.hello(2,3))
