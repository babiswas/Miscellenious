def fun1(str1):
   return str1

def fun2(str2):
   return str2

m=type('A',(object,),{"display1":fun1,"display2":fun2})
print(m.display1("hello World"))
print(m.display2("hello world 2"))
