from abc import ABC,abstractmethod

class Handle(ABC):
   def __init__(self,sucessor):
      self.sucessor=sucessor
   def handle(self,request):
      handled=self._handle(request)
      if not handled:
         self.sucessor.handle(request)
   @abstractmethod
   def _handle(self,request):
      pass

class CoreHandle(Handle):
   def _handle(self,request):
       if request>=0 and request<=10:
          print(f"Request processed {request}")
          return True
       
class DefaultHandle(Handle):
   def _handle(self,request):
      print(f"End of chain {request}")
      return True

class Client:
   def __init__(self):
       self.handler=CoreHandle(DefaultHandle(None))
   def delegate(self,requests):
      for i in requests:
         self.handler.handle(i)



if __name__=="__main__":
   l=[1,2,3,10,12,4,5,10]
   m=Client()
   m.delegate(l)

   
   
   
      