from abc import ABC,abstractmethod
class Handler(ABC):
   def __init__(self,sucessor):
       self.sucessor=sucessor
   def handle(self,request):
     handled=self._handle(request)
     if not handled:
         self.sucessor.handle(request)
   @abstractmethod
   def _handle(self,request):
       pass

class DefaultHandler(Handler):
     def _handle(self,request):
       print(f"End of chain {request}")
       return True
class ConcreteHandler(Handler):
     def _handle(self,request):
       if request>=0 and request<=10:
          print(f"Request processed {request}")
          return True
class Client:
   def __init__(self):
       self.handler=ConcreteHandler(DefaultHandler(None))
   def delegate(self,requests):
      for request in requests:
          self.handler.handle(request)
if __name__=="__main__":
   requests=[12,13,14,15,2,3,1]
   c=Client()
   c.delegate(requests)

   
   