import types
class Strategy:
   def __init__(self,function=None):
      self.name="Default Strategy"
      if function:
         self.execute=types.MethodType(function,self)
   def execute(self):
      print(f"Default Strategy Executed")

def execute1(self):
    print(f"{self.name} is executed")

def execute2(self):
    print(f"{self.name} is executed")

if __name__=="__main__":
   s=Strategy()
   s.execute()
   s1=Strategy(execute1)
   s1.name="test1"
   s1.execute()
   s2=Strategy()
   s2.name="test2"
   s2.execute()
