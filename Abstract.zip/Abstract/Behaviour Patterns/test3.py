import types
class Strategy:
   def __init__(self,function=None):
      self.name="Default Strategy"
      if function:
        self.execute=types.MethodType(function,self)
   def execute(self):
      print(f"Default Strategy executed")

def strategy_1(self):
    print(f"{self.name} strategy 1 executed")

def strategy_2(self):
    print(f"{self.name} strategy 2 executed")

if __name__=="__main__":
   s1=Strategy()
   s1.execute()
   s2=Strategy(strategy_1)
   s2.name="test1"
   s2.execute()
   s3=Strategy(strategy_2)
   s3.name="test2"
   s3.execute()

