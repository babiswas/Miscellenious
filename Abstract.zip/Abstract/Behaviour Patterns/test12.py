class Client:

   def __init__(self,name):
       self.name=name

   def update(self,message):
     print(f"{message} recieved by {self.name}")


class Observer:

   def __init__(self):
     self.obj=[]
   def register(self,ob):
      if ob not in self.obj:
        self.obj.append(ob)
   def unregister(self,ob):
      if ob  in self.obj:
        self.obj.remove(ob)
   def notify(self,message):
      for i in self.obj:
         i.update(message)

if __name__=="__main__":
   ob=Observer()
   cl1=Client("test1")
   cl2=Client("test2")
   cl3=Client("test3")
   ob.register(cl1)
   ob.register(cl2)
   ob.register(cl3)
   ob.notify("hello every body")


      