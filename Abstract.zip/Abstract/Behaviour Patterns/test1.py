class Observer:
    def __init__(self):
       self.obj=[]
    def register(self,obj1):
       if obj1 not in self.obj:
           self.obj.append(obj1)
    def unregister(self,obj1):
       if obj1 in self.obj:
          self.obj.remove(obj1)
    def notify(self,message):
       for ob in self.obj:
          ob.update(message)

class Observable:
   def __init__(self,name):
      self.name=name
   def update(self,message):
      print(f"{self.name} got message {message}")

if __name__=="__main__":
   ob=Observer()
   ob1=Observable("test1")
   ob2=Observable("test2")
   ob3=Observable("test3")
   ob.register(ob1)
   ob.register(ob2)
   ob.register(ob3)
   ob.notify("hello all")

    