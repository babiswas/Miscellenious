from abc import ABC,abstractmethod

class House:
   def accept(self,visitor):
      visitor.visit(self)
   def work_on_elec(self,elec):
      print(f"Working on {elec}")
   def work_on_hvac(self,hvac):
      print(f"Working on {hvac}")

class Visitor(ABC):
   def __init__(self,name):
       self.name=name
   @abstractmethod
   def visit(self,house):
      pass
   def __str__(self):
       return f"{self.name}"

class Elec(Visitor):
   def __init__(self,name):
       self.name=name
   def visit(self,house):
     house.work_on_elec(self)

class Hvac(Visitor):
   def __init__(self,name):
       self.name=name
   def visit(self,house):
       house.work_on_hvac(self)

if __name__=="__main__":
   house=House()
   e=Elec("testing electric")
   f=Hvac("testing hvac")
   house.accept(e)
   house.accept(f)
