from abc import ABC,abstractmethod
class House:
   def accept(self,visitor):
      visitor.visit(self)
   def work_on_elec(self,elec):
     print(f"{elec} working on electrical")
   def work_on_hvac(self,hvac):
     print(f"{hvac} working on hvac")

class Visitor(ABC):
   def __init__(self,name):
      self.name=name
   @abstractmethod
   def visit(self,house):
      pass

class Elec(Visitor):
   def __init__(self,name):
      Visitor.__init__(self,name)
   def visit(self,house):
      house.work_on_elec(self)

class Hvac(Visitor):
   def __init__(self,name):
     Visitor.__init__(self,name)
   def visit(self,house):
     house.work_on_hvac(self)

if __name__=="__main__":
   e=Elec("test1")
   f=Hvac("test2")
   h=House()
   h.accept(e)
   h.accept(f)


   