from abc import ABC,abstractmethod
class House:
    def accept(self,visitor):
        visitor.visit(self)
    def work_on_elec(self,elec):
        print(f"work on {elec}")
    def work_on_plumb(self,plum):
        print(f"work on {plum}")

class Visitor:
   def __init__(self,name):
     self.name=name

   @abstractmethod
   def visit(self,house):
      pass

class Elec(Visitor):
   def __init__(self,name):
      self.name=name
   def __str__(self):
     return f"{self.name}"
   def visit(self,house):
       house.work_on_elec(self)

class Plum(Visitor):
    def __init__(self,name):
       self.name=name
    def __str__(self):
      return f"{self.name}"
    def visit(self,house):
       house.work_on_plumb(self)

if __name__=="__main__":
   e=Elec("test1")
   f=Plum("test2")
   h=House()
   h.accept(e)
   h.accept(f)

   

     

