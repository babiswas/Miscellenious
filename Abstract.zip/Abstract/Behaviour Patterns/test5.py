class Observable:
   def __init__(self,name):
      self.name=name

   def update(self,message):
       print(f"{self.name} recieved {message}")

class Observer:
  def __init__(self):
     self.obj=[]

  def register(self,ob):
    if ob not in self.obj:
      self.obj.append(ob)

  def unregister(self,ob):
    if ob in self.obj:
        self.obj.append(ob)

  def notify(self,message):
     for ob in self.obj:
        ob.update(message)

if __name__=="__main__":
  ob1=Observable("test1")
  ob2=Observable("test2")
  ob=Observer()
  ob.register(ob1)
  ob.register(ob2)
  ob.notify("Hello All")
