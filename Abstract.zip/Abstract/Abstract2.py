from abc import ABC,abstractmethod

class A(ABC):
   def __init__(self,a,b):
      self.a=a
      self.b=b
   
   @staticmethod
   @abstractmethod
   def sum(a,b):
     pass

   @property
   @abstractmethod
   def seta(self):
      pass

   @seta.setter
   @abstractmethod
   def seta(self,a):
      pass
  
   @abstractmethod
   def display(self):
       pass

class B(A):
   def __init__(self,*args):
      A.__init__(self,*args)

   @staticmethod
   def sum(a,b):
      return a+b

   @property
   def seta(self):
      return self.a

   @seta.setter
   def seta(self,a):
     self.a=a

   def display(self):
      return f"{self.a} and {self.b}"

if __name__=="__main__":
   b=B(2,3)
   print(b.display())
   b.seta=24
   print(b.seta)

   
