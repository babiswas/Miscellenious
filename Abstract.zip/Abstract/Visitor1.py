#Visitor Design Pattern
from abc import ABC,abstractmethod

class House:
    def accept(self,visitor):
        visitor.visit(self)

    def work_on_hvac(self,elec):
      print(f"{elec} working on hvac")

    def work_on_plumber(self,plum):
       print(f"{plum} working on plumber")
        

class Visitor(ABC):
   def __init__(self,name):
        self.name=name
   def __str__(self):
      return f"{self.name}"

   @abstractmethod
   def visit(self):
      pass

class Electrician(Visitor):
    def __init__(self,name):
       self.name=name

    def visit(self,house):
        house.work_on_hvac(self)

class Plumber(Visitor):
    def __init__(self,name):
       self.name=name

    def visit(self,house):
        house.work_on_plumber(self)

if __name__=="__main__":
   e=Electrician("hello")
   p=Plumber("bello")
   house=House()
   house.accept(e)
   house.accept(p)

   
   


