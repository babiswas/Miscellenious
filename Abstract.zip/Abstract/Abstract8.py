from contextlib import contextmanager

@contextmanager
def fun(name):
  try:
    m=open(name,'w')
    yield m
  finally:
    m.close()


if __name__=="__main__":
  with fun("mello.txt") as d:
    d.write("test1\n")
    d.write("test2\n")
