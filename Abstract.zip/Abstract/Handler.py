from abc import ABC,abstractmethod

class Handler:
   def __init__(self,sucessor):
      self._sucessor=sucessor

   def handle(self,request):
      handled=self._handle(request)
      if not handled:
         self._sucessor.handle(request)

   @abstractmethod
   def _handle(self,request):
      pass


class ConcreteHandler1(Handler):
    def _handle(self,request):
        if 0<request<=10:
           print(f"{request} handled in handler1")
           return True

class DefaultHandler(Handler):
   def _handle(self,request):
      print(f"End of chain {request}")
      return True

class Client:
   def __init__(self):
      self.handler=ConcreteHandler1(DefaultHandler(None))

   def delegate(self,requests):
      for request in requests:
         self.handler.handle(request)

if __name__=="__main__":
   requests=[2,5,30]
   c=Client()
   c.delegate(requests)




