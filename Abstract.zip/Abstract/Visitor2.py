from abc import ABC,abstractmethod

class House:

   def accept(self,visitor):
      visitor.visit(self)

   def work_on_hvac(self,hvac):
     print(f"work on hvac {hvac}")

   def work_on_elec(self,elec):
     print(f"work on elec {elec}")

class Visitor:
   def __init__(self,name):
      self.name=name

   def __str__(self):
      return f"{self.name}"

   @abstractmethod
   def visit(self,house):
      pass

class Elec(Visitor):
   def __init__(self,name):
      self.name=name
   def visit(self,house):
      house.work_on_elec(self)

class Hvac(Visitor):
   def __init__(self,name):
      self.name=name
   def visit(self,house):
      house.work_on_hvac(self)

if __name__=="__main__":
   house=House()
   vis1=Elec("Electrician")
   vis2=Hvac("HighVoltage")
   house.accept(vis1)
   house.accept(vis2)

