class Observable:
   def __init__(self,name):
      self.name=name

   def update(self,message):
      print(f"{self.name} recieved {message}")


class Observer:
  def __init__(self):
     self.obj=[]

  def register(self,obj1):
     if obj1 not in self.obj:
       self.obj.append(obj1)

  def unregister(self,obj1):
     if obj1 in self.obj:
       self.obj.remove(obj1)

  def notify(self,message):
     for i in self.obj:
       i.update(message)

if __name__=="__main__":
   o1=Observable("test1")
   o2=Observable("test2")
   o3=Observable("test3")
   ob=Observer()
   ob.register(o1)
   ob.register(o2)
   ob.register(o3)
   ob.notify("hello 100")


