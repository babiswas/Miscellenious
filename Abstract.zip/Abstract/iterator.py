def count_to(count):
   no_in_german=["eins","zwei","drei","vier","funf"]
   iterator=zip(range(count),no_in_german)
   for i in iterator:
       print(i[0])
   for position,number in iterator:
         yield number

for num in count_to(3):
    print(f"{num}")

