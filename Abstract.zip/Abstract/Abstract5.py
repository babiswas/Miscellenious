def my_meta(classname,baseclass,attrs):
    def fun1(self):
       return self.a
    attrs["hello"]=fun1
    return type(classname,baseclass,attrs)

class A(metaclass=my_meta):
    def __init__(self,a,b):
       self.a=a
       self.b=b
    def __str__(self):
      return f"{self.a} and {self.b}"

if __name__=="__main__":
   a=A(2,3)
   print(a)
   print(a.hello())

