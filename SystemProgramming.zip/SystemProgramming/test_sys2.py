import sys
x=5
y=4
print(type(sys.modules))
m=sys.modules
print(m['sys'])
#print(m)
print('sys' in m)




