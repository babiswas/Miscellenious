import sys
print(sys.getwindowsversion())
