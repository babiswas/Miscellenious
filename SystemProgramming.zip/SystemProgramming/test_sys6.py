import sys
def test_fun():
   a=2
   b=3
   return a+b
if __name__=="__main__":
  sys.stdout=open("hello",'w')
  print(test_fun())