import sys

def sample_name():
    try:
      if sys.argv[1]=="hello":
         print("hello")
      elif sys.argv[1]=="bye":
         sys.exit(2)
    except Exception as e:
      print("No input provided")
   
    print("Task Complete")

if __name__=="__main__":
   sample_name()
