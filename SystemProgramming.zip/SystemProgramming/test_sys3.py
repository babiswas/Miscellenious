import sys
print(sys.platform)
