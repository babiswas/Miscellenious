import sys
print("Priting python version")
print(sys.version)
print("The copyright")
print(sys.copyright)
#Helps to find the location of the interpreater.
print(sys.executable)
#Built in module names
print(sys.builtin_module_names)

