import numpy as np
a=np.array([[1,2,3],[0,4,5],[7,0,0]])
b=a>4
a[b]=-1
print(a[b])

import numpy as np
a=np.array([[1,2,3],[5,6,7]])
b=np.array([[5,6,7],[8,9,10]])
print(np.hstack(a,b))
print(np.vstack(a,b))

import numpy as np
a=np.array([[1,2,3],[4,5,6]])
b=np.array([[7,8,9],[5,6,7]])
print(a[:,2])
print(a[:,1])
print(a[:,0])
print(b[0:1,1])
print(b[0:2,0])

import numpy as np
a=np.arange(30).reshape(3,10)
a=np.hsplit(a,3)






