def display(str1):
   return str1


m=type('A',(object,),{"display":display,"var":4})

if __name__=="__main__":
  print(m.display("hello"))
  print(m.var)


