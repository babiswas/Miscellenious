def hello(str1):
  return str1

m=type('A',(object,),{"bello":hello})
print(m.bello("feddd"))