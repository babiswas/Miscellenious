def fun(str1):
  print(str1)

def fun2(str2):
  print(str2)

m=type('A',(object,),{"hello":fun,"bello":fun2})

if __name__=="__main__":
  m.hello("hello")
  m.bello("bello")

