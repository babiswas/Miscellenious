class Mymeta(type):
   def __new__(metaclass,classname,baseclass,attrs):
       def fun(self):
          print("Hello")
       attrs["fun"]=fun
       return type.__new__(metaclass,classname,baseclass,attrs)

   def __init__(self,classname,baseclass,attrs):
       pass

class A(metaclass=Mymeta):
     def __init__(self,a,b):
         self.a=a
         self.b=b
     def __str__(self):
        return f"{self.a} and {self.b} is the value"

if __name__=="__main__":
   a=A(2,3)
   print(a)
   a.fun()
