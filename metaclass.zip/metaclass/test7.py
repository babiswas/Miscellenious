def meta(classname,baseclass,attrs):
   def name(self):
     return "hello"
   attrs["hello"]=name
   return type(classname,baseclass,attrs)

mymeta=meta

class B(metaclass=meta):
   def __init__(self,a):
       self.a=a
   def __str__(self):
       return f"{self.a} is the value"

if __name__=="__main__":
   n=B(2)
   print(n)
   print(n.hello())

    