def meta(classname,baseclass,attrs):
    def fun(self):
      print("Hello")
    attrs["hello"]=fun
    return type(classname,baseclass,attrs)

class A(metaclass=meta):

   def __init__(self,a,b):
      self.a=a
      self.b=b

   def __str__(self):
      return f"{self.a} and {self.b}"

if __name__=="__main__":
   a=A(2,3)
   print(a)
   a.hello()



     