def bello(str1):
   return str1

def hello(str2):
   print(str2)

m=type('A',(object,),{'fun1':bello,'fun2':hello,'name':"hello1"})

if __name__=="__main__":
   print(m.fun1("tello"))
   m.fun2("chello")
   print(m.name)
   
 