def meta_func(name,bases,attrs):
   nattrs={'mod'+key:attrs[key] for key in attrs}
   return type(name,bases,nattrs)

MyMeta=meta_func

class Kls(metaclass=MyMeta):
   def send(self,data):
      self.data=data
   def getd(self):
      return self.data


k=Kls()
print(Kls.__dict__)
k.modsend(12)
print(k.modgetd())
k.modsend(24)
print(k.modgetd())



