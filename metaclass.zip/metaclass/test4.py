class Mymeta(type):
   def __call__(clsname,*args):
       instance=object.__new__(clsname)
       instance.__init__(*args)
       return instance

class Kls(metaclass=Mymeta):
    def __init__(self,data):
       self.data=data
    def printd(self):
       print(self.data)

ik=Kls('arun')
ik.printd()
