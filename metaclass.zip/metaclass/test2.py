class A:
  def __init__(self,a):
     self.a=a
  def display(self):
     return self.a

class Mymeta(type):
   def __new__(metaclass,classname,baseclass,attrs):
       attrs['getdata']=A.__dict__['display']
       return type.__new__(metaclass,classname,baseclass,attrs)

   def __init__(self,*args):
       pass

class B(metaclass=Mymeta):
   def __init__(self,a,b):
       self.a=a
       self.b=b
   def __str__(self):
     return f"{self.a} and {self.b}"


if __name__=="__main__":
   b=B(2,3)
   print(b)
   print(b.getdata())

