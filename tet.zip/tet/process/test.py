def function(i):
   print(f"Value of the process is {i}")
