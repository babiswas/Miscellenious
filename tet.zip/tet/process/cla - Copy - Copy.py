class A:
  def __init__(self,a):
     self.a=a
  def __repr__(self):
     return f"{self.a}"