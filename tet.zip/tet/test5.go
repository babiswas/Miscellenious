package main
import "fmt"

func main(){
 var myarr[3]int
 fmt.Println("Elements of the array is:",myarr)
}