def hello(str1):
  return "hello"

m=type('A',(object,),{'bello':hello})
print(m.__dict__)
print(m.bello("bello"))