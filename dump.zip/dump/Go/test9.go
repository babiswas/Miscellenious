package main
import "fmt"

func display(){
  fmt.Println("Hello")
  return
}

func main(){
   display()
}
