package main
import "fmt"

func display(){
   fmt.Println("Hello")
}