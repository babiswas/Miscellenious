package main
import "fmt"

func main(){
  var num[3] int
  num[0]=1
  num[1]=2
  num[2]=3
  for i:=0;i<3;i++{
   fmt.Println(i)
}
}