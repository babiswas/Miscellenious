package main
import (
       "fmt"
       "math"
       )
type Circle struct{
   x,y,r int
}

func (c Circle)area()float64{
  return math.Pi*float64(c.r)*float64(c.r)
}

func main(){
  c:=Circle{2,2,5}
  fmt.Println(c.x,c.y,c.r)
  fmt.Println(c.area())
}