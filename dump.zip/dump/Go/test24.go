package main
import "fmt"

type Student struct{
  name string
  id,age int
}

func (s Student)get_name()string{
   return s.name
}

func (s Student)get_age()int{
   return s.age
}

func (s Student)get_id()int{
   return s.id
}

func (*s Student)set_student(id,age int,name string){
  s.name=name
  s.age=age
  s.id=id
}

func (*s Student)get_student()(int,int,string){
    return s.id,s.age,s.name
}

func main(){
  s:=Student{"Bapan",21,35}
  fmt.Println(s.get_name())
  fmt.Println(s.get_age())
  fmt.Println(s.get_id())
  m:=new(Student)
  m.set_student(12,21,"Bello")
  id,age,name:=get_student()
  fmt.Println(id)
  fmt.Println(age)
  fmt.Println(name)
}

