package main
import "fmt"

type user struct{
  name string
  age int
}

func create_user(name string,age int)(*user){
  u:=user{name,age}
  return &u
}

func (c *user)display(){
  fmt.Println(c.name)
  fmt.Println(c.age)
}

func main(){
  m:=create_user("Bapan",21)
  m.display()
  k:=create_user("Tapan",34)
  k.display()
}