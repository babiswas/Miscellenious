package main
import "fmt"

func increment(p *int){
  *p=*p+10
}

func main(){
 count:=0
 p:=&count
 increment(p)
 increment(p)
 fmt.Println(count)
 increment(p)
 increment(p)
 fmt.Println(count)
}