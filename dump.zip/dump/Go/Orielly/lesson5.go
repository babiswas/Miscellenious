package main
import "fmt"

type num struct{
 a,b int
 name string
}

type bum struct{
 c,d int
 name string
}

func (e bum)display(){
  fmt.Println(e.c)
  fmt.Println(e.d)
  fmt.Println(e.name)
}

func (e num)display1(){
  fmt.Println(e.a)
  fmt.Println(e.b)
  fmt.Println(e.name)
}

func main(){
  var e1 num
  var e2 bum
  e3:=num{1,2,"Hello"}
  fmt.Println("Printing values of bum")
  e2.display()
  fmt.Println("Printing values of num")
  e1.display1()
  e1=e3
  e1.display1()
}