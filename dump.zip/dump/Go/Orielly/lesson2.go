package main
import "fmt"

type example struct{
  flag bool
  counter int16
  pi float32
}

func main(){
  var e1 example
  e1=example{false,21,3.12}
  fmt.Println(e1.counter)
  fmt.Println(e1.flag)
  fmt.Println(e1.pi)
}