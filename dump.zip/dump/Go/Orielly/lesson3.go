package main
import "fmt"

type num struct{
  a,b int
  c float64
}

func (c *num)display(){
  fmt.Println(c.a)
  fmt.Println(c.b)
  fmt.Println(c.c)
}

func main(){
  m:=num{}
  m.display()
  n:=num{1,2,3.45}
  fmt.Println("Displayed struct")
  n.display()
}