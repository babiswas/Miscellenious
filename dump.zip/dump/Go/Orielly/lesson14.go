package main
import "fmt"

type user struct{
  name string
  age int
}

func display(m *user){
  fmt.Println(m.name)
  fmt.Println(m.age)
}

func createuser()(*user){
  return &user{"Bello",21}
}

func main(){
  m:=createuser()
  display(m)
}