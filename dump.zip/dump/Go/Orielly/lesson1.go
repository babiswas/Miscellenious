package main
import "fmt"

func main(){
  var num int
  var name string
  var num1 int
  var num2 float64
  var num3 string
  num3="Hello World"
  num=2
  name="Bapan"
  num2=54.66
  a:=24
  b:="Hello Bello"
  c:=12.54
  fmt.Println(num)
  fmt.Println(name)
  fmt.Println(num1)
  fmt.Println(num2)
  fmt.Println(num3)
  fmt.Println(a)
  fmt.Println(b)
  fmt.Println(c)
}