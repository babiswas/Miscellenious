package main
import "fmt"

func greet(c chan string){
  for i:=0;i<10;i++{
   str1:="Hello"
   c<-str1
  }
}

func main(){
  var data string
  fmt.Println("Main program started")
  c:=make(chan string)
  go greet(c)
  for j:=0;j<10;j++{
    data=<-c
    fmt.Println(data)   
  }
}