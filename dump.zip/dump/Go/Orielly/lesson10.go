package main
import "fmt"

type user struct{
  name string
  age int
}

func update(m *user,name string,a int){
  m.name=name
  m.age=a
}

func (u *user)display(){
   fmt.Println(u.name)
   fmt.Println(u.age)
}

func main(){
  m:=user{"Halder",12}
  m.display()
  update(&m,"Bapan",21)
  m.display()
}