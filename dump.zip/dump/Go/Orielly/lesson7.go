package main
import "fmt"

func main(){
  var count int
  count=0
  fmt.Println(count)
  count++
  fmt.Println(count)
  count++
  fmt.Println(count)
}