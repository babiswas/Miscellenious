package main
import "fmt"

func increment(a int)int{
  a=a+1
  return a
}

func main(){
  count:=0
  count=increment(count)
  fmt.Println(count)
  count=increment(count)
  fmt.Println(count)
  count=increment(count)
  fmt.Println(count)
}

