package main
import "fmt"



func main(){
  var e1 struct{
      a,b int
      name string
  }
  e1.a=12
  e1.b=24
  e1.name="Hello Hello"
  fmt.Println(e1.a)
  fmt.Println(e1.b)
  fmt.Println(e1.name)
}