package main
import "fmt"

func main(){
 num:=12
 if num>13{
    fmt.Println("Number is greater than 13")
}else{
  fmt.Println("Number is less than 13")
}
}