class Cell:
   def __init__(self,x,dist):
       self.x=x
       self.dist=dist

def isinside(x,N):
  if x<0 or x>=N:
     return False
  return True


def array_end(arr):
   dx=[1,-1]
   queue=[]
   visited=[False]*len(arr)
   queue.append(Cell(0,0))
   visited[0]=True
   while queue:
      m=queue.pop(0)
      if m.x==len(arr)-1:
         return m.dist
      for i in range(2):
         x=m.x+dx[i]
         if isinside(x,len(arr)):
           if visited[x]==False:
                queue.append(Cell(x,m.dist+1))
                visited[x]=True
      index=[i for i,j in enumerate(arr) if arr[i]==m.x]
      for i in index:
          if not visited[i]:
            queue.append(Cell(i,m.dist+1))
            visited[i]==True
   return -1
if __name__=="__main__":
   l=[0,1,2,3,4,5,6,7,5,4,3,6,0,1,2,3,4,5,7]
   print(array_end(l))

   
