def longest_palindromic_seq(str1):
     maxm=0
     table=[[0 for i in range(len(str1))] for i in range(len(str1))]
     if len(str1)>2:
        for i in range(len(str1)):
            table[i][i]=1
            maxm=1
        for i in range(len(str1)):
          if i+1<len(str1):
             if str1[i]==str1[i+1]:
                table[i][i+1]=2
             else:
                table[i][i+1]=1
             if table[i][i+1]>maxm:
                maxm=table[i][i+1]
        for i in range(3,len(str1)):
          for j in range(len(str1)):
            if i+j-1<len(str1):
               if str1[j]==str1[i+j-1]:
                  table[j][i+j-1]=table[j+1][i+j-2]+2
               else:
                  table[j][i+j-1]=max(table[j][i+j-2],table[j+1][i+j-1])
               if table[j][i+j-1]>maxm:
                  maxm=table[j][i+j-1]
        print(maxm)
        print(table)
if __name__=="__main__":
  longest_palindromic_seq("tessdgfwwesgrrdd")
  longest_palindromic_seq("jggxwsntkksqsssfffs")
   
