package main
import (
       "fmt"
       "math"
       )
type Circle struct{
   x,y,r int
}

func main(){
  c:=Circle{0,0,5}
  fmt.Println(c.x,c.y,c.r)
}