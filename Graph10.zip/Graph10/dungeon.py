class Cell:
   def __init__(self,x,y,dist):
       self.x=x
       self.y=y
       self.dist=dist

def isinside(x,y,M,N):
    if x<0 or x>=N:
       return False
    if y<0 or y>=N:
       return False
    if M[x][y]=='#':
       return False
    return True

def dungeon(kpos,tpos,M,N):
    dx=[1,-1,0,0]
    dy=[0,0,-1,1]
    queue=[]
    queue.append(Cell(kpos[0],kpos[1],0))
    visited=[[False for i in range(N)] for i in range(N)]
    visited[kpos[0]][kpos[1]]=True
    while queue:
       m=queue.pop(0)
       if m.x==tpos[0] and m.y==tpos[1]:
         return m.dist
       for i in range(4):
         x=m.x+dx[i]
         y=m.y+dy[i]
         if isinside(x,y,M,N):
            if visited[x][y]==False:
               queue.append(Cell(x,y,m.dist+1))
               visited[x][y]==True
    return -1

if __name__=="__main__":
   M=[[3,3,1,'#'],[3,'#',3,3],[2,3,'#',3],['#',3,3,3]]
   kpos=[0,2]
   tpos=[2,0]
   print(dungeon(kpos,tpos,M,len(M)))

