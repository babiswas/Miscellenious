def BFS(n,m,num):
   queue=[]
   queue.append(num)
   while queue:
      stepping_no=queue.pop(0)
      if stepping_no>=n and stepping_no<=m:
         print(stepping_no)
      if num==0 or stepping_no>m:
          continue
      lastdigit=stepping_no%10
      na=stepping_no*10+(lastdigit-1)
      nb=stepping_no*10+(lastdigit+1)
      if lastdigit==0:
         queue.append(nb)
      elif lastdigit==9:
         queue.append(na)
      else:
         queue.append(na)
         queue.append(nb)

def display(n,m):
   for i in range(0,10):
      BFS(n,m,i)

if __name__=="__main__":
  display(0,100)





         
      